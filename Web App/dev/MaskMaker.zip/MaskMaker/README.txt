
To Run:

py -O main.py










controls:
left click - draw the mask
ctrl + left click - remove mask
right click - move around
scroll - zoom 
ctrl + scroll -change brush size
a - hides the mask
q - saves the mask as a numpy bool array as mask.npy
