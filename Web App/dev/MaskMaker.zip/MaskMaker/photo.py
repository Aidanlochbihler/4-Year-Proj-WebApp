from PIL import Image
import numpy as np
import pyglet
from pyglet.gl import *
from collections import defaultdict
Image.MAX_IMAGE_PIXELS=999999999



class keydefaultdict(defaultdict):
    def __missing__(self, key):
        if self.default_factory is None:
            raise KeyError( key )
        else:
            ret = self[key] = self.default_factory(key)
            return ret


class PixSprite(pyglet.sprite.Sprite):
    def __init__(self, *args, **kwargs):
        super(PixSprite, self).__init__(*args, **kwargs)
        glBindTexture(GL_TEXTURE_2D, self._texture.id)
        glTexParameteri(self._texture.target, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
        glTexParameteri(self._texture.target, GL_TEXTURE_MIN_FILTER, GL_NEAREST)

mode_to_bytes = {"L": 1, "P": 1, "RGB":3 , "RGBA": 4, "CMYK": 4, "YCbCr": 3, "LAB": 3, "HSV": 3, "I": 4, "F": 4}

def array_to_sprite(array, pos, batch=None, mode='RGBA'):
	
	raw_image = Image.fromarray(np.rot90(array,k=1,axes=(0,1))).tobytes()
	image = pyglet.image.ImageData(array.shape[0], array.shape[1], mode, raw_image, pitch=-array.shape[0] * mode_to_bytes[mode])
	return PixSprite(image, pos[0], pos[1], batch=batch)


class sub_array():
	def __init__(self,pos, batch, empty_arr, full_img, array=None, full=False, empty=True):
		
		self.pos=pos
		self.batch=batch
		self.empty_arr=empty_arr
		self.full_img=full_img

		self.array=array
		self.full=full
		self.empty=empty
		self.sprite=None
		self.mode="RGBA"


	def make_empty(self):
		self.full=False
		self.empty=True
		self.array=None
		if self.sprite != None:
			self.sprite.delete()
			self.sprite=None
	
	def make_full(self):
		if not self.full:
			self.full=True
			self.empty=False
			self.array=None
			if self.sprite != None:
				self.sprite.delete()
				self.sprite=None

			self.sprite = PixSprite(self.full_img, self.pos[0]*16, self.pos[1]*16, batch=self.batch)

	def colour_square(self,lx_min,lx_max,ly_min,ly_max):
		if self.full==False:
			self.empty=False
			if self.sprite != None:
					self.sprite.delete()
					self.sprite=None

			if self.array is None:
				self.array = self.empty_arr.copy()
				self.array[lx_min:lx_max,ly_min:ly_max,3] = 100
			else:
				self.array[lx_min:lx_max,ly_min:ly_max,3] = 100
			self.sprite = array_to_sprite(self.array, (self.pos[0]*16, self.pos[1]*16), self.batch)

	def uncolour_square(self,lx_min,lx_max,ly_min,ly_max):
		if self.empty==False:
			self.full=False
			if self.sprite != None:
					self.sprite.delete()
					self.sprite=None

			if self.array is None:
				self.array = self.empty_arr.copy()
				self.array[:,:,3] += 100
				self.array[lx_min:lx_max,ly_min:ly_max,3] = 0
			else:
				self.array[lx_min:lx_max,ly_min:ly_max,3] = 0
			self.sprite = array_to_sprite(self.array, (self.pos[0]*16, self.pos[1]*16), self.batch)

	def get_bool(self):
		
		if self.empty:
			ret = np.zeros((16,16),dtype=bool)
		elif self.full:
			ret = np.ones((16,16),dtype=bool)
		else:
			ret = self.array[:,:,3].astype(bool)
		return ret




class Base():
	def __init__(self,array,mode):
		self.mode_to_bytes = {"L": 1, "P": 1, "RGB":3 , "RGBA": 4, "CMYK": 4, "YCbCr": 3, "LAB": 3, "HSV": 3, "I": 4, "F": 4}
		# im = Image.open("dog-puppy-on-garden-royalty-free-image-1586966191.jpg").convert("RGBA")
		# array = np.array(im)
		self.mode = mode
		self.shape = array.shape
		self.textures =[]
		self.make_textures(array, 0, 0)



	

	def make_textures(self,array,x,y,size=pyglet.image.get_max_texture_size()):
		max_size = max(pyglet.image.get_max_texture_size(), size)
		ymiddle = array.shape[0]//2
		xmiddle = array.shape[1]//2
		if array.shape[0] > max_size:
			self.make_textures(array[:ymiddle],x,y)
			self.make_textures(array[ymiddle:],x,y+ymiddle)
		elif array.shape[1] > max_size:
			self.make_textures(array[:, :xmiddle],x+xmiddle,y)
			self.make_textures(array[:, xmiddle:],x,y)
		else:
			
			raw_image = Image.fromarray(array).tobytes()
			# image = pyglet.image.ImageData(image.width, image.height, image.mode, raw_image, pitch=-image.width * self.mode_to_bytes[image.mode])
			image = pyglet.image.ImageData(array.shape[1], array.shape[0], self.mode, raw_image, pitch=-array.shape[1] * self.mode_to_bytes[self.mode])
			image.anchor_x = x
			image.anchor_y = y

			self.textures.append(image.get_texture()) 

	def draw(self):
		for t in self.textures:
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)
			t.blit(0, 0)





class Mask():

	def __init__(self,shape):
		
		
		self.batch=pyglet.graphics.Batch()

		self.mode_to_bytes = {"L": 1, "P": 1, "RGB":3 , "RGBA": 4, "CMYK": 4, "YCbCr": 3, "LAB": 3, "HSV": 3, "I": 4, "F": 4}

		self.mode = "RGBA"
		self.shape = shape
		self.textures =[]


		# self.red_blue=np.zeros((16,16),dtype=np.uint8)+20
		# self.green=np.zeros((16,16),dtype=np.uint8)+200
		# self.alpha_full=np.zeros((16,16),dtype=np.uint8)+100
		self.empty = np.zeros((16,16),dtype=np.uint8)

		empty_arr = np.stack([self.empty+20, self.empty+220, self.empty+20, self.empty], axis=2)
		raw_full =Image.fromarray(np.stack([self.empty+20, self.empty+220, self.empty+20, self.empty+100],axis=2)).tobytes()
		self.image_full = pyglet.image.ImageData(16, 16, self.mode, raw_full, pitch=-16 * self.mode_to_bytes[self.mode])
		self.arrays = keydefaultdict(lambda key:sub_array(key,self.batch,empty_arr,self.image_full))



	def draw(self):



		self.batch.draw()




	def square_brush_add(self,point,radius):
		x_min = point[0]-radius
		x_max = point[0]+radius+1
		y_min = point[1]-radius
		y_max = point[1]+radius+1

		for cx in range(x_min//16, x_max//16+1):
			for cy in range(y_min//16, y_max//16+1):
				a = self.arrays[(cx,cy)]

				if radius>100:
					a.make_full()


				elif (cx==x_min//16 or cx==x_max//16 or cy==y_min//16 or cy==y_max//16 ) and not a.full:
					lx_min=0
					lx_max=16

					ly_min=0
					ly_max=16

					if cx==x_min//16:
						lx_min = x_min%16

					if cx==x_max//16:
						lx_max = x_max%16

					if cy==y_min//16:
						ly_min = y_min%16

					if cy==y_max//16:
						ly_max = y_max%16

					a.colour_square(lx_min, lx_max, ly_min,ly_max)

				else:
					a.make_full()


	def square_brush_remove(self,point,radius):
		x_min = point[0]-radius
		x_max = point[0]+radius+1
		y_min = point[1]-radius
		y_max = point[1]+radius+1

		for cx in range(x_min//16, x_max//16+1):
			for cy in range(y_min//16, y_max//16+1):
				a = self.arrays[(cx,cy)]

				if radius>100:
					if not(a.empty):
						a.make_empty()

				elif (cx==x_min//16 or cx==x_max//16 or cy==y_min//16 or cy==y_max//16 ) and not a.empty:
					lx_min=0
					lx_max=16

					ly_min=0
					ly_max=16

					if cx==x_min//16:
						lx_min = x_min%16

					if cx==x_max//16:
						lx_max = x_max%16

					if cy==y_min//16:
						ly_min = y_min%16

					if cy==y_max//16:
						ly_max = y_max%16

					a.uncolour_square(lx_min, lx_max, ly_min,ly_max)

				else:
					if not(a.empty):
						a.make_empty()

	def save(self):
		mask=np.zeros((self.shape[1],self.shape[0]),dtype=bool)
		for a in self.arrays:
			mask[a[0]*16:a[0]*16+16, a[1]*16:a[1]*16+16] = self.arrays[a].get_bool()

		np.save('mask', np.rot90(mask), allow_pickle=False)




class Brush_Overlay():
	def __init__(self, current_radius =100, radius_max=1000):

		self.mode_to_bytes = {"L": 1, "P": 1, "RGB":3 , "RGBA": 4, "CMYK": 4, "YCbCr": 3, "LAB": 3, "HSV": 3, "I": 4, "F": 4}
		self.mode = "RGBA"

		self.radius_max=radius_max
		self.current_radius = current_radius
		self.red_green=np.zeros((radius_max+1,radius_max+1),dtype=np.uint8)+20
		self.blue=np.zeros((radius_max+1,radius_max+1),dtype=np.uint8)+200
		self.alpha=np.zeros((radius_max+1,radius_max+1),dtype=np.uint8)

		self.empty = np.stack([self.red_green, self.red_green, self.blue, self.alpha],axis=2)

		self.change_size((0,0) , current_radius)

		

	def change_location(self,point):

		self.sprite.update(point[0]-self.radius_max+self.current_radius/2, point[1]-self.radius_max+self.current_radius/2)


	def change_size(self,point,radius):
		temp = self.empty.copy()
		self.current_radius = int(round(radius*2))
		if self.current_radius==1:
			temp[self.radius_max,self.radius_max,3] =100
		else:
			temp[self.radius_max-self.current_radius:self.radius_max+self.current_radius+1,
				self.radius_max-self.current_radius:self.radius_max+self.current_radius+1,3] =100
		self.sprite=array_to_sprite(temp, (0, 0))
		self.change_location(point)

	def draw(self):
		self.sprite.draw()


class Photo(Base):
	def __init__(self,path):
		im = Image.open(path).convert("RGBA")
		super().__init__(np.array(im),"RGBA")

