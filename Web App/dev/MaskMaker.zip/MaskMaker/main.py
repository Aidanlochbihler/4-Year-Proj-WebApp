import pyglet 
import glooey
from pyglet.gl import *
from pyglet.window import key , mouse
from photo import Mask, Photo, Brush_Overlay

import re
from os import listdir


# Zooming constants
ZOOM_IN_FACTOR = 2
ZOOM_OUT_FACTOR = 1/ZOOM_IN_FACTOR

class App(pyglet.window.Window):

	def __init__(self, width, height, *args, **kwargs):
		conf = Config(sample_buffers=1,
					  samples=4,
					  depth_size=16,
					  double_buffer=True)
		super().__init__(width, height, config=conf, *args, **kwargs)

		#Initialize camera values
		self.left   = 0
		self.right  = width
		self.bottom = 0
		self.top    = height
		self.zoom_level = 1
		self.zoomed_width  = width
		self.zoomed_height = height


		for d in listdir():
			if re.search(r"\.(?:jpg|jpeg|tif|tiff|png|bmp)",d):
				self.photo=Photo(d)
				break
		
		# self.photo=Photo("pixel-ruler.png")
		# self.photo=Photo("12222008Slide3.tif")
		self.mask=Mask(self.photo.shape)

		self.brush_radius = 32
		self.brush = Brush_Overlay(self.brush_radius )

		self.show_mask = True
		



	def init_gl(self, width, height):
		# Set clear color
		glClearColor(200/255, 100/255, 0/255, 0/255)

		# Set antialiasing
		# glEnable( GL_LINE_SMOOTH )
		# glEnable( GL_POLYGON_SMOOTH )
		# glHint( GL_LINE_SMOOTH_HINT, GL_NICEST )

		# Set alpha blending
		glEnable( GL_BLEND )
		# glBlendFunc( GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA )

		# Set viewport
		glViewport( 0, 0, width, height )

		pyglet.gl.glBlendFunc(pyglet.gl.GL_SRC_ALPHA,pyglet.gl.GL_ONE_MINUS_SRC_ALPHA)





	def on_resize(self, width, height):
		# super().on_resize(width, height)
		# Set window values
		self.left   = 0
		self.right  = width
		self.bottom = 0
		self.top    = height
		self.zoom_level = 1
		self.zoomed_width  = width
		self.zoomed_height = height
		self.width  = width
		self.height = height

		self.init_gl(width, height)



	def on_mouse_press(self, x, y, buttons, modifiers):
		if buttons & mouse.LEFT:

			mouse_x = x/self.width
			mouse_y = y/self.height
			mouse_x_in_world = int(self.left   + mouse_x*self.zoomed_width)
			mouse_y_in_world = int(self.bottom + mouse_y*self.zoomed_height)
			if modifiers == key.MOD_CTRL:
				self.mask.square_brush_remove((mouse_x_in_world,mouse_y_in_world),int(self.brush_radius))
			else:
				self.mask.square_brush_add((mouse_x_in_world,mouse_y_in_world),int(self.brush_radius))
		

	def on_mouse_drag(self, x, y, dx, dy, buttons, modifiers):
		# Move camera
		if buttons & mouse.RIGHT:

			self.left   -= dx*self.zoom_level
			self.right  -= dx*self.zoom_level
			self.bottom -= dy*self.zoom_level
			self.top    -= dy*self.zoom_level
		
		if buttons & mouse.LEFT:
			mouse_x = x/self.width
			mouse_y = y/self.height
			mouse_x_in_world = int(self.left   + mouse_x*self.zoomed_width)
			mouse_y_in_world = int(self.bottom + mouse_y*self.zoomed_height)
			self.brush.change_location((mouse_x_in_world,mouse_y_in_world))
			if modifiers == key.MOD_CTRL:
				self.mask.square_brush_remove((mouse_x_in_world,mouse_y_in_world),int(self.brush_radius))
			else:
				self.mask.square_brush_add((mouse_x_in_world,mouse_y_in_world),int(self.brush_radius))

		# self.mask.circle_brush((x,y),100)


	def on_mouse_motion(self, x, y, dx, dy):
		mouse_x = x/self.width
		mouse_y = y/self.height
		mouse_x_in_world = int(self.left   + mouse_x*self.zoomed_width)
		mouse_y_in_world = int(self.bottom + mouse_y*self.zoomed_height)
		self.brush.change_location((mouse_x_in_world,mouse_y_in_world))



	def on_mouse_scroll(self, x, y, dx, dy):
		modifiers = self._get_modifiers()
		if modifiers == key.MOD_CTRL:
			if not(dy<0 and self.brush_radius < .5) and dy<0:
				self.brush_radius = min(1000, self.brush_radius * 2)
			if  dy>0:
				self.brush_radius = max(0.5, self.brush_radius / 2)
			mouse_x = x/self.width
			mouse_y = y/self.height
			mouse_x_in_world = int(self.left   + mouse_x*self.zoomed_width)
			mouse_y_in_world = int(self.bottom + mouse_y*self.zoomed_height)


			self.brush.change_size((mouse_x_in_world,mouse_y_in_world),self.brush_radius)


		else:
			dy = -dy
			# Get scale factor
			f = ZOOM_IN_FACTOR if dy > 0 else ZOOM_OUT_FACTOR if dy < 0 else 1
			# If zoom_level is in the proper range
			if .1 < self.zoom_level*f < 100:

				self.zoom_level *= f
				if self.zoom_level>=1:
					self.zoom_level = int(round(self.zoom_level))
				mouse_x = x/self.width
				mouse_y = y/self.height

				mouse_x_in_world = self.left   + mouse_x*self.zoomed_width
				mouse_y_in_world = self.bottom + mouse_y*self.zoomed_height

				self.zoomed_width  *= f
				self.zoomed_height *= f
				self.left   = mouse_x_in_world - mouse_x*self.zoomed_width
				self.right  = mouse_x_in_world + (1 - mouse_x)*self.zoomed_width
				self.bottom = mouse_y_in_world - mouse_y*self.zoomed_height
				self.top    = mouse_y_in_world + (1 - mouse_y)*self.zoomed_height


	def on_key_press(self, symbol, modifiers):

		if symbol == key.A:
			self.show_mask = False
		if symbol == key.Q:
			self.mask.save()

	def on_key_release(self, symbol, modifiers):

		if symbol == key.A:
			self.show_mask = True




	def on_draw(self):
		# Initialize Projection matrix
		
		glMatrixMode( GL_PROJECTION )
		glLoadIdentity()

		# Initialize Modelview matrix
		# glMatrixMode( GL_MODELVIEW )
		# glLoadIdentity()
		# Save the default modelview matrix
		glPushMatrix()

		# Clear window with ClearColor
		glClear( GL_COLOR_BUFFER_BIT )

		# Set orthographic projection matrix
		glOrtho( self.left, self.right, self.bottom, self.top, 1, 0 )
		# self.image.draw()
		# Draw quad
		self.photo.draw()
		if self.show_mask:
			self.mask.draw()
		self.brush.draw()

		# Remove default modelview matrix
		glPopMatrix()
	def run(self):
		pyglet.app.run()


if __name__ == '__main__':
	app = App(500, 500,resizable=True)

	keys = key.KeyStateHandler()
	app.push_handlers(keys)


	app.run()

